package tools.placeworkers.com.productexplorer;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.apache.olingo.odata2.api.ep.entry.ODataEntry;
import org.apache.olingo.odata2.api.exception.ODataException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mListView = findViewById(R.id.products);

        GetFeedTask task = new GetFeedTask();
        List<ODataEntry> products = null;
        try {
            products = task.execute().get();
            String[] listItems = new String[products.size()];
            for(int i = 0; i < products.size(); i++){
                ODataEntry product = products.get(i);
                listItems[i] = product.getProperties().get("Price").toString();
            }
            ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listItems);
            mListView.setAdapter(adapter);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

    class GetFeedTask extends AsyncTask<Void,Void,List<ODataEntry>>{

        @Override
        protected List<ODataEntry> doInBackground(Void... voids) {
            try {
                List<ODataEntry> products =  new ProductClient().GetProducts().getEntries();
                return products;
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ODataException e) {
                e.printStackTrace();
            }
            return new ArrayList<>();
        }
    }
}
