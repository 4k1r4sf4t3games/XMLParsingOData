package tools.placeworkers.com.xmlparsing;

import org.apache.olingo.odata2.api.ep.feed.ODataFeed;
import org.apache.olingo.odata2.api.exception.ODataException;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {

    @Test
    public void products() throws IOException, ODataException {
        ODataFeed products  = new ProductClient().GetProducts();
        assertEquals(9, products.getEntries().size());
    }

}