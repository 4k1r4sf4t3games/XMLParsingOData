package tools.placeworkers.com.xmlparsing;

import android.support.v7.app.AppCompatActivity;

import org.apache.olingo.odata2.api.ep.feed.ODataFeed;
import org.apache.olingo.odata2.api.exception.ODataException;

import java.io.IOException;


public class MainActivity extends AppCompatActivity {


    public void products() throws IOException, ODataException {
        ODataFeed products = new ProductClient().GetProducts();

    }
}



